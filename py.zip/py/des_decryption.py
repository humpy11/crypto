IP = [
58,50,42,34,26,18,10,2,
60,52,44,36,28,20,12,4,
62,54,46,38,30,22,14,6,
64,56,48,40,32,24,16,8,
57,49,41,33,25,17,9,1,
59,51,43,35,27,19,11,3,
61,53,45,37,29,21,13,5,
63,55,47,39,31,23,15,7
]

IP_INV = [
40,8,48,16,56,24,64,32,
39,7,47,15,55,23,63,31,
38,6,46,14,54,22,62,30,
37,5,45,13,53,21,61,29,
36,4,44,12,52,20,60,28,
35,3,43,11,51,19,59,27,
34,2,42,10,50,18,58,26,
33,1,41,9,49,17,57,25
]

E = [
32,1,2,3,4,5,
4,5,6,7,8,9,
8,9,10,11,12,13,
12,13,14,15,16,17,
16,17,18,19,20,21,
20,21,22,23,24,25,
24,25,26,27,28,29,
28,29,30,31,32,1
]

P = [
16,7,20,21,
29,12,28,17,
1,15,23,26,
5,18,31,10,
2,8,24,14,
32,27,3,9,
19,13,30,6,
22,11,4,25
]

SBOX = [
[
[14,4,13,1,2,15,11,8,3,10,6,12,5,9,0,7],
[0,15,7,4,14,2,13,1,10,6,12,11,9,5,3,8],
[4,1,14,8,13,6,2,11,15,12,9,7,3,10,5,0],
[15,12,8,2,4,9,1,7,5,11,3,14,10,0,6,13]
]
]*8


def permute(bits, table):
    return [bits[i-1] for i in table]

def xor(a,b):
    return [i^j for i,j in zip(a,b)]

def sbox_sub(bits):
    out=[]
    for i in range(8):
        block = bits[i*6:(i+1)*6]
        row = block[0]*2 + block[5]
        col = block[1]*8 + block[2]*4 + block[3]*2 + block[4]
        val = SBOX[i][row][col]
        out += [int(x) for x in format(val,'04b')]
    return out


def feistel(R, key):
    R_exp = permute(R,E)
    x = xor(R_exp,key)
    s = sbox_sub(x)
    return permute(s,P)


print("Enter 64-bit ciphertext:")
cipher = list(map(int,input().split()))

keys = [[1,0]*24 for _ in range(16)]

keys = keys[::-1]

ip = permute(cipher,IP)

L = ip[:32]
R = ip[32:]

for i in range(16):

    temp = L
    L = R
    R = xor(temp, feistel(R, keys[i]))

combined = R + L

plaintext = permute(combined,IP_INV)

print("\nDecrypted Plaintext:")
print(plaintext)