def caesar_encrypt(text, key):
    result = ""
    for c in text:
        if c.isalpha():
            shift = (ord(c.upper()) - 65 + key) % 26
            result += chr(shift + 65)
        else:
            result += c
    return result

def caesar_decrypt(text, key):
    return caesar_encrypt(text, -key)

text = "HELLO"
key = 3

enc = caesar_encrypt(text, key)
dec = caesar_decrypt(enc, key)

print("Encrypted:", enc)
print("Decrypted:", dec)