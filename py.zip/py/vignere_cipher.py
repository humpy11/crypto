def vigenere_encrypt(text, key):
    result = ""
    key = key.upper()
    j = 0

    for c in text.upper():
        if c.isalpha():
            shift = ord(key[j % len(key)]) - 65
            result += chr((ord(c) - 65 + shift) % 26 + 65)
            j += 1
        else:
            result += c
    return result

def vigenere_decrypt(text, key):
    result = ""
    key = key.upper()
    j = 0

    for c in text:
        if c.isalpha():
            shift = ord(key[j % len(key)]) - 65
            result += chr((ord(c) - 65 - shift) % 26 + 65)
            j += 1
        else:
            result += c
    return result

text = "HELLO"
key = "KEY"

enc = vigenere_encrypt(text, key)
dec = vigenere_decrypt(enc, key)

print("Encrypted:", enc)
print("Decrypted:", dec)