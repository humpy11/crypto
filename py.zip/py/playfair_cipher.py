def generate_key_matrix(key):
    key = key.upper().replace("J", "I")
    matrix = []
    used = set()

    for c in key + "ABCDEFGHIKLMNOPQRSTUVWXYZ":
        if c not in used:
            used.add(c)
            matrix.append(c)

    return [matrix[i:i+5] for i in range(0,25,5)]

def find(matrix, c):
    for i in range(5):
        for j in range(5):
            if matrix[i][j] == c:
                return i,j

def playfair_encrypt(text, key):
    matrix = generate_key_matrix(key)
    text = text.upper().replace("J","I")

    if len(text)%2 != 0:
        text += "X"

    result = ""

    for i in range(0,len(text),2):
        a,b = text[i],text[i+1]
        r1,c1 = find(matrix,a)
        r2,c2 = find(matrix,b)

        if r1 == r2:
            result += matrix[r1][(c1+1)%5] + matrix[r2][(c2+1)%5]
        elif c1 == c2:
            result += matrix[(r1+1)%5][c1] + matrix[(r2+1)%5][c2]
        else:
            result += matrix[r1][c2] + matrix[r2][c1]

    return result

print(playfair_encrypt("HELLO","MONARCHY"))